function varargout = ImageCompression1(varargin)

% Our Projects focuses on significant compression of the image sizes
% without much loss in quality. We follow following steps for compression
% 1- Input Original Image
% 2- Convert Images in to double precision image vectors
% 3- Discrete Cosine Transform Matrix Processing of the image
% 4- Quantizaion of Image by Masking
% 5- Compressed Image


%GUI INTERFACE FOR INPUTTING IMAGE

gui_Singleton = 1;
%creating a structure array with specific fields and values for setting up
%the structure of the gui interface for user interaction.
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ImageCompression1_OpeningFcn, ...
                   'gui_OutputFcn',  @ImageCompression1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);

               
% use of nargin to check whether some argument was passed as  nargin returns
% the number of input arguments that were used to call the
% function. 
% collects the input into the variable "varargin"
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
% executed if some outputs are returnes as nargout returns the
% number of output arguments that were used to call the function.
 
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ImageCompression1 is made visible.
function ImageCompression1_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for ImageCompression1
handles.output = hObject;

% Update handles structure for GUI Interface
guidata(hObject, handles);
guidata(hObject, handles);
set(handles.axes1,'visible','off')
set(handles.axes2,'visible','off')
axis off
axis off
% UIWAIT makes ImageCompression1 wait for user response 
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ImageCompression1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data 

varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data 
global file_name;
%guidata(hObject,handles)
%accesses the image file to be compressed by the user based on the provided specific file type
file_name=uigetfile({'*.bmp;*.jpg;*.png;*.tiff;';'*.*'},'Select an Image File');
fileinfo = dir(file_name);
% stores size in bytes in variable SIZE
SIZE = fileinfo.bytes;
% for storing size in Kilo Bytes
Size = SIZE/1024;
set(handles.text7,'string',Size);
imshow(file_name,'Parent', handles.axes1)

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    the handle to pushbutton2 
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global file_name;

%check for checking whether the user select and passes the valid image
if(~ischar(file_name))
   errordlg('Please select Images first');
else
    I1 = imread(file_name);

% 2- CONVERT IMAGE TO DOUBLE PRECISION IMAGES 

I = I1(:,:,1);
%converts image file in to double vector values for later processing
I = im2double(I);
%Discrete Cosine Transform of Order 8

% 3- DISCRETE COSINE TRANSFORM
T = dctmtx(8);
%distinct block processing for image processing
B = blkproc(I,[8 8],'P1*x*P2',T,T');

% 4- QUANTIZATION BY MASKING
mask = [1   1   1   1   0   0   0   0
        1   1   1   0   0   0   0   0
        1   1   0   0   0   0   0   0
        1   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0];
    
%   blkproc(B,[8 8],'P1.*x',mask) defines an overlapping 
%   border around the blocks.  blkproc extends the original 8 by 8 blocks by
%   the value which is product of P1.*x on the top and bottom, and on the left and right. blkproc pads
%   the border with zeros, if necessary, on the edges of B. mask should
%   operate on the extended block.
B2 = blkproc(B,[8 8],'P1.*x',mask);
I2 = blkproc(B2,[8 8],'P1*x*P2',T',T);

I = I1(:,:,2);
I = im2double(I);
T = dctmtx(8);
B = blkproc(I,[8 8],'P1*x*P2',T,T');
mask = [1   1   1   1   0   0   0   0
        1   1   1   0   0   0   0   0
        1   1   0   0   0   0   0   0
        1   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0];
B2 = blkproc(B,[8 8],'P1.*x',mask);
I3 = blkproc(B2,[8 8],'P1*x*P2',T',T);


I = I1(:,:,3);
%    takes an image as input, and returns an image of class double.  If
%    the input image is of class double, the output image is identical to it
I = im2double(I);
% discrete cosine transform matrix of order 8
T = dctmtx(8);
B = blkproc(I,[8 8],'P1*x*P2',T,T');
mask = [1   1   1   1   0   0   0   0
        1   1   1   0   0   0   0   0
        1   1   0   0   0   0   0   0
        1   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0
        0   0   0   0   0   0   0   0];
B2 = blkproc(B,[8 8],'P1.*x',mask);
I4 = blkproc(B2,[8 8],'P1*x*P2',T',T);


L(:,:,:)=cat(3,I2, I3, I4);
imwrite(L,'CompressedColourImage.jpg');
% 5- COMPRESSED IMAGE
% stores the output compresed file in the same directory with the
% ComressedColourImage.jpg name
fileinfo = dir('CompressedColourImage.jpg');
SIZE = fileinfo.bytes;
% calculates the size of output image in Kilo Bytes
Size = SIZE/1024;
set(handles.text8,'string',Size);
imshow(L,'Parent', handles.axes2)
end
